from crewai import Task

from agents.assistant import assistant


def build_assistant_task(question: str):

    return Task(

        description=f"""
You are the first AI assistant.

Customer Question:

{question}

Answer using your existing knowledge only.

Do not use internet search.

Be professional, concise and helpful.
""",

        expected_output="""
A clear customer support response based only on existing knowledge.
""",

        agent=assistant

    )