from crewai import Task

from agents.researcher import researcher


def build_research_task(question: str):

    return Task(

        description=f"""
Customer Question:

{question}

Review the previous assistant response.

Use the Internet Search Tool to verify facts.

If newer or better information exists,
provide an improved answer.

If the assistant answer is already correct,
confirm it.

Always explain what you found.
""",

        expected_output="""
An updated and verified answer using internet search.
""",

        agent=researcher

    )