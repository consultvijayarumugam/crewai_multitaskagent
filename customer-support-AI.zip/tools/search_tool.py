from crewai.tools import tool
from langchain_community.tools import DuckDuckGoSearchRun

search = DuckDuckGoSearchRun()


@tool("Internet Search Tool")
def internet_search(query: str) -> str:
    """
    Search the internet for the latest information.
    """

    try:
        return search.run(query)

    except Exception as e:
        return f"Search failed: {str(e)}"