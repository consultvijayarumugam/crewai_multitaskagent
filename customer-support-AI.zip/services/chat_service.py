history = self.memory.get_history(username)

conversation_history = ""

for item in history[-10:]:
    conversation_history += (
        f"{item['role']}: {item['content']}\n"
    )